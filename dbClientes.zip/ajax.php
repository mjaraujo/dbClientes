<?php
    if (!empty($_POST)){
        echo "<pre>";
        print_r($_POST);
        echo "</pre>";
        
    }else{
        echo ("dados carregados...");
    }
?>