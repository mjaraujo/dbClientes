<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Logradouro
 *
 * @author marcio
 */
class Logradouro {

    private $log_cep;
    private $log_nome;
    private $log_tipo;
    private $log_bairro;
    private $log_timestamp;
    private $cid_id;
    
    

}
