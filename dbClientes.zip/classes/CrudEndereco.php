<?php

include_once ('../classes/Endereco.php');
include_once '../bd/DB.php';

class CrudCliente extends Endereco {

    function __construct() {
        parent::__construct($id, $end_complemento, $end_numero, $cli_id, $loc_id);
    }

    function buscarPeloCEP($CEP) {
        $sql = 'select * from Endereco';
        $stmt = DB::prepare($sql, array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
        $stmt->execute();
    }

}

?>